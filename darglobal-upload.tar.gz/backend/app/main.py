"""FastAPI application entry point."""

import logging

from fastapi import FastAPI

from app.api.routes import router

logging.basicConfig(level=logging.INFO)

app = FastAPI(
    title="Real Estate Intelligence Chatbot API",
    description="Grounded answers from public DarGlobal and Wasalt information.",
    version="0.1.0",
)
app.include_router(router)
